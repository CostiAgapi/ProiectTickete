<?php
class Ticket{

    private $departament="";
    private $email="";
    private $subiect="";
    private $mesaj="";
    private $referinta="";

    private $errEmail="";
    private $errSubiect="";
    private $errMesaj="";
    private $errNotFound="Ticketul nu a fost gasit";

    private $erori_from_post=false;
    private $erori_from_get=false;

    public function __construct(PDO $conn) {

      if($_SERVER['REQUEST_METHOD']=='POST'){
      try{
      $this->setDataFromPost();
      if($this->erori_from_post == false){
        $this->putInDatabase($conn);
        echo "Ticketul a fost creat cu succes";
      }else{
        echo $this->errEmail.$this->errSubiect.$this->errMesaj;
      }
    }
    catch(PDOException $e) {
      echo "EROARE Ticketul nu a fost creat:";
      $e->getMessage();
    }

  }else{
    try{
    if($this->setDataFromDatbase($conn)===false){
      echo "a mers";
    }else{
      echo "nu mers";
    }
  }catch(PDOException $e) {
    $e->getMessage();
  }
  }
  }

    private function putInDatabase(PDO $conn){
      $sql="INSERT INTO `Tickets` (
        `Referinta`, `Departament`, `Email`, `Subiect`, `Mesaj`
      ) VALUES
      ('".generateRandomReference()."',
      '".$this->departament."',
      '".$this->email."',
      '".$this->subiect."',
      '".$this->mesaj."'
      );";
      $conn->exec($sql);
    }

    private function setDataFromDatbase(PDO $conn){
        $this->referinta = $_GET['referinta'];
        $sql="SELECT * FROM `Tickets` WHERE `Referinta` = '".$this->referinta."'";
        $q = $conn->query($sql);
        $q->setFetchMode(PDO::FETCH_ASSOC);
        $r = $q->fetch();
        if(!empty($r['Departament'])){
          $this->departament = $r['Departament'];
        }else{
          $this->erori_from_get=true;
        }
        if(!empty($r['Email'])){
          $this->email = $r['Email'];
        }else{
          $this->erori_from_get=true;
        }
        if(!empty($r['Subiect'])){
          $this->subiect = $r['Subiect'];
        }else{
          $this->erori_from_get=true;
        }
        if(!empty($r['Mesaj'])){
          $this->mesaj = $r['Mesaj'];
        }else{
          $this->erori_from_get=true;
        }
        return $this->erori_from_get;
    }

  private function setDataFromPost(){
    $this->departament=$_POST['nume_departament'];

      if(!empty($_POST['email'])){
        $this->email= $_POST['email'];
      }else{
        $this->errEmail="Introduce-ti mail";
        $this->erori_from_post =true;
      }

      if(!empty($_POST['subiect'])){
        $this->subiect= $_POST['subiect'];
      }
      else{
        $this->errSubiect="Introduce-ti subiect";
        $this->erori_from_post =true;
      }

      if(!empty($_POST['continut_mesaj'])){
        $this->mesaj= $_POST['continut_mesaj'];
      }else{
        $this->errMesaj="Introduce-ti mesaj";
        $this->erori_from_post =true;
      }
  }
}



function generateRandomReference(){
  $str="";
  $char="0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
  $str.=$char[rand(0, strlen($char) - 1)];
  $str.=$char[rand(0, strlen($char) - 1)];
  $str.="-";
  $str.=$char[rand(0, strlen($char) - 1)];
  $str.=$char[rand(0, strlen($char) - 1)];
  $str.=$char[rand(0, strlen($char) - 1)];
  return $str;
}


?>
