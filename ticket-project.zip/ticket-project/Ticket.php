<?php
class Ticket{

    private $departament="";
    private $email="";
    private $subiect="";
    private $mesaj="";
    private $referinta="";

    private $succes_or_fail_message="";

    private $errEmail="";
    private $errSubiect="";
    private $errMesaj="";
    private $errNotFound="Ticketul nu a fost gasit";

    private $erori_from_post=false;
    private $erori_from_get=false;

    public function __construct(PDO $conn) {

      //  folosind formularul din post
      if(isset($_POST['submit'])){
        try{
        $this->setDataFromPost();
        if($this->erori_from_post == false){
          $this->putInDatabase($conn);
          $this->succes_or_fail_message="<div class='alert alert-success'>
                                    <strong>Succes !</strong> Ticketul a fost creat
                                  </div>";
        }else{
          $this->succes_or_fail_message = "<div class='alert alert-danger'>
                                      <strong>Creare esuata!</strong> Verificati erorile de mai jos.
                                    </div>";
        }
      }
      catch(PDOException $e) {
        echo "EROARE Ticketul nu a fost creat:";
        $e->getMessage();
      }
    }
    // folosind campul referinta pentru pagina de view
    if ((isset($_GET['referinta']))){
      try{
      if($this->setDataFromReferinta($conn)===false){
        //echo "a mers";
      }else{
        if(empty($this->referinta)){
          $_SESSION['message']="field_gol";
        }else{
          $_SESSION['message']="nu_exista";
        }
        header("Location: index.php");
      }
      }catch(PDOException $e) {
      $e->getMessage();
      }
    }

    // if($_SERVER['REQUEST_METHOD']=='GET'){
    //   //
    // }
  }

    private function putInDatabase(PDO $conn){
      $sql="INSERT INTO `Tickets` (
        `Referinta`, `Departament`, `Email`, `Subiect`, `Mesaj`
      ) VALUES
      ('".generateRandomReference()."',
      '".$this->departament."',
      '".$this->email."',
      '".$this->subiect."',
      '".$this->mesaj."'
      );";
      $conn->exec($sql);
    }

    private function setDataFromReferinta(PDO $conn){
        $this->referinta = $_GET['referinta'];
        $sql="SELECT * FROM `Tickets` WHERE `Referinta` = '".$this->referinta."'";
        $q = $conn->query($sql);
        $q->setFetchMode(PDO::FETCH_ASSOC);
        $r = $q->fetch();
        if(!empty($r['Departament'])){
          $this->departament = $r['Departament'];
        }else{
          $this->erori_from_get=true;
        }
        if(!empty($r['Email'])){
          $this->email = $r['Email'];
        }else{
          $this->erori_from_get=true;
        }
        if(!empty($r['Subiect'])){
          $this->subiect = $r['Subiect'];
        }else{
          $this->erori_from_get=true;
        }
        if(!empty($r['Mesaj'])){
          $this->mesaj = $r['Mesaj'];
        }else{
          $this->erori_from_get=true;
        }
        return $this->erori_from_get;
    }

  private function setDataFromPost(){
      $this->departament=$_POST['nume_departament'];

      if(!empty($_POST['email'])){
        $this->email= $_POST['email'];
      }else{
        $this->errEmail="Introduce-ti mail";
        $this->erori_from_post =true;
      }

      if(!empty($_POST['subiect'])){
        $this->subiect= $_POST['subiect'];
      }
      else{
        $this->errSubiect="Introduce-ti subiect";
        $this->erori_from_post =true;
      }

      if(!empty($_POST['continut_mesaj'])){
        $this->mesaj= $_POST['continut_mesaj'];
      }else{
        $this->errMesaj="Introduce-ti mesaj";
        $this->erori_from_post =true;
      }
  }
  public function getReferinta(){
    return $this->referinta;
  }
  public function getDepartament(){
    return $this->departament;
  }

  public function getSubiect(){
    return $this->subiect;
  }

  public function getEmail(){
    return $this->email;
  }

  public function getTicketMessage(){
    return $this->mesaj;
  }

  public function getSuccesOrFailMessage(){
    return $this->succes_or_fail_message;
  }

  public function getErrorEmailMessage(){
    return $this->errEmail;
  }

  public function getErrorSubiectMessage(){
    return $this->errSubiect;
  }

  public function getErrorContentMessage(){
    return $this->errMesaj;
  }
}

function generateRandomReference(){
  $str="";
  $char="0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
  $str.=$char[rand(0, strlen($char) - 1)];
  $str.=$char[rand(0, strlen($char) - 1)];
  $str.="-";
  $str.=$char[rand(0, strlen($char) - 1)];
  $str.=$char[rand(0, strlen($char) - 1)];
  $str.=$char[rand(0, strlen($char) - 1)];
  return $str;
}


?>
