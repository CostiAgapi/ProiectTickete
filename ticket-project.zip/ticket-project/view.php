<?php
require ("DB.php");
require ("Ticket.php");

      $hostname="localhost";
      $dbname="tickets_project";
      $username="root";
      $password="constantin";

  if(empty($_GET['referinta'])){
    echo "nu ati introdus nimic";
    // pus buton back
  }else{
    $db = new DB($hostname,$dbname,$username,$password);
    try{
      $ticket = new Ticket($db);
    }catch(PDOException $e){
      echo "Ticketul nu exista";
    }

  //  echo var_dump($ticket);
  }

 ?>
