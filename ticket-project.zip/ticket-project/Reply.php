<?php
class Reply{

  private $mesaj_reply="";
  private $mesaj_eroare = "";

  public static $ARRAY_REFERINTE=array();
  public static $i=0; // de facut private
  private static $reply_deja_bagat = false;  // verific daca s-a bagat deja in baza de date un reply din post

  public static function populateArrayReferinte(PDO $conn){
    $array_ref = array();
    $sql="SELECT `ID_Reply` FROM `Replies` WHERE `ID_Ticket` = '".$_GET['referinta']."' ORDER BY `ID_Reply` ASC ";

    foreach ($conn->query($sql) as $referinta){
        array_push($array_ref,$referinta);
      }
      return $array_ref;
  }

  public static function getRepliesList(PDO $conn){
    $array_reply=array();
      foreach (static::$ARRAY_REFERINTE as $ref){
        array_push($array_reply,new self($conn));
      }
    return $array_reply;
  }


  public function __construct(PDO $conn) {

    if($_SERVER['REQUEST_METHOD']=="POST"){
      if(static::$reply_deja_bagat==false){
        $this->setDataFromPost();
        $this->putInDatabase($conn);
        static::$reply_deja_bagat = true;
      }else{
        $this->setDataFromReference($conn);
      }

    }else{
      $this->setDataFromReference($conn);
    }

  }

  private function setDataFromPost(){
    if(!empty($_POST['reply'])){
      $this->mesaj_reply= $_POST['reply'];
    }else{
      $this->mesaj_eroare = "<div class='alert alert-danger'>
                              <strong>Introudce-ti comment </strong>
                            </div>";
    }
  }

    private function setDataFromReference(PDO $conn){

      $sql="SELECT * FROM `Replies` WHERE `ID_Ticket` = '".$_GET['referinta']."' AND `ID_Reply` = '".static::$ARRAY_REFERINTE[static::$i]["ID_Reply"]."'";
      $q = $conn->query($sql);
      $q->setFetchMode(PDO::FETCH_ASSOC);
      $r = $q->fetch();
      $this->mesaj_reply= $r['Mesaj'];
      static::$i++;
  }

  private function putInDatabase(PDO $conn){
    $sql="INSERT INTO `Replies` (
      `ID_Ticket`, `Mesaj`
    ) VALUES
    ('".$_GET['referinta']."',
    '".$this->mesaj_reply."',
    );";
    $conn->exec($sql);
  }

  public function getErrorMessage(){
    return $this->mesaj_eroare;
  }

  public function getReplyMessage(){
    return $this->mesaj_reply;
  }

  public function generateReplyHTML(){
        $reply_html = "<div class='panel panel-default arrow left' style='border-color: ".$_SESSION['reply_color'].";'>
                              <div class='panel-body'>
                                <div class='comment-post'>
                                  <p>
                                    ".$this->mesaj_reply."
                                    </p>
                                  </div>
                                </div>
                              </div>";
        return $reply_html;
  }

}



 ?>
