<?php
error_reporting(E_ALL); ini_set('display_errors', '1');
require ("DB.php");
require ("Ticket.php");

  $hostname="localhost";
  $dbname="tickets_project";
  $username="root";
  $password="constantin";

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $db = new DB($hostname,$dbname,$username,$password);
    $ticket = new Ticket($db);
}

 ?>

 <!DOCTYPE html>
 <html lang="en">

 <head>

     <meta charset="utf-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1">
     <meta name="description" content="">
     <meta name="author" content="">

     <title>Ticket Project</title>

     <!-- Bootstrap Core CSS -->
     <link href="css/bootstrap.min.css" rel="stylesheet">

     <!-- Custom CSS -->
     <style>
     body {
         padding-top: 70px;
         /* Required padding for .navbar-fixed-top. Remove if using .navbar-static-top. Change if height of navigation changes. */
     }
     </style>

     <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
     <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
     <!--[if lt IE 9]>
         <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
         <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
     <![endif]-->

 </head>

 <body>

     <!-- Navigation -->
     <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
         <div class="container">
             <!-- Brand and toggle get grouped for better mobile display -->
             <div class="navbar-header">
                 <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                     <span class="sr-only">Toggle navigation</span>
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                 </button>
                 <a class="navbar-brand" href="#">Start Bootstrap</a>
             </div>
             <!-- Collect the nav links, forms, and other content for toggling -->
             <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                 <ul class="nav navbar-nav">
                     <li>
                         <a href="#">About</a>
                     </li>
                     <li>
                         <a href="#">Services</a>
                     </li>
                     <li>
                         <a href="#">Contact</a>
                     </li>
                 </ul>
             </div>
             <!-- /.navbar-collapse -->
         </div>
         <!-- /.container -->
     </nav>

     <!-- Page Content -->
     <div class="container">

         <div class="row">
             <div class="col-lg-6 text-center">
                 <h1>Ticket Creation</h1>
                 <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
                   <div class="form-group">
                    <label for="nume_departament">Departament: </label>
                    <select name="nume_departament" class="form-control" id="nume_departament">
                      <option>Departament Tehnic</option>
                      <option>Departament Marketing</option>
                      <option>Departament Economic</option>
                    </select>
                  </div>
                   <div class="form-group">
                     <label for="adresa_email">Email address</label>
                     <input type="email" name="email" class="form-control" id="adresa_email" aria-describedby="emailHelp">
                     <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                   </div>
                   <div class="form-group">
                     <label for="subiect">Subiect</label>
                     <input type="text" name="subiect" class="form-control" id="subiect">
                   </div>
                   <div class="form-group">
                       <label for="continut_mesaj">Example textarea</label>
                       <textarea  name="continut_mesaj" class="form-control" id="continut_mesaj" rows="3"></textarea>
                     </div>
                     <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                 </form>

             </div>
         </div>
         <!-- /.row -->

         <div class="row">
           <h1>Ticket Search</h1>
           <form method="get" action="<?php echo htmlspecialchars("view.php");?>">
             <div class="form-group">
               <label for="referinta">Subiect</label>
               <input type="text" name="referinta" class="form-control" id="referinta">
             </div>
             <button type="submit" class="btn btn-primary">View</button>
           </form>
         </div>

     </div>
     <!-- /.container -->

     <!-- jQuery Version 1.11.1 -->
     <script src="js/jquery.js"></script>

     <!-- Bootstrap Core JavaScript -->
     <script src="js/bootstrap.min.js"></script>

 </body>

 </html>
